package org.example;

public interface Observer {
    void update(Object observable, Object arg);
}
