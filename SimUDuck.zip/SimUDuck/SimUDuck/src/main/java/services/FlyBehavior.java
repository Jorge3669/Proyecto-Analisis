package services;

public interface FlyBehavior {

    public void fly();

}
