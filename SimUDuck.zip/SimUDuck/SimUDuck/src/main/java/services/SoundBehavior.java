package services;

public interface SoundBehavior {
    public void makeSound();
}
